package app_app_5;

import java.util.Scanner;

public class B {
public static void main(String[] args) {
	Scanner scan = new Scanner (System.in);
	System.out.println("enter the number:");
	
    int x = scan.nextInt();
	if(x==100){
		System.out.println("A");
		
	}
	else if (x==200) {
		System.out.println("B");
	}
	else {
		System.out.println("0C");
		
	}
}
}

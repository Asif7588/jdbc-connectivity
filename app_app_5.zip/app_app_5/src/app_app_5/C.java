package app_app_5;

public class C {
public static void main(String[] args) {
	int key = 2;
	switch (key) {
	case 1:
	     System.out.println(1);
	
	case 2:
         System.out.println(2);
         
	case 3:
		 System.out.println(3);
		 break;
	default:
		System.out.println(6);
	
	}
}
}

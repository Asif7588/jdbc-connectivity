package app_app_5;

import java.util.Scanner;

public class A {
	
public static void main(String[] args) {
	Scanner scan = new Scanner (System.in);
	System.out.println("Enter your name");
	String name = scan.next();
	System.out.println("your name is"+name);
	System.out.println("enter your age");
	int age = scan.nextInt();
	System.out.println("your age is"+age);
	System.out.println("enter yor weight");
	float weight = scan.nextFloat();
	System.out.println("your weight is"+weight);
}
}


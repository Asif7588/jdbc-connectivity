package jdbc_app_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class C {
 public static void main(String[] args) {
	try {
		//connect to db
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_db_1", "root", "As@962383");
		
	System.out.println(con);	
	//create statements
	Statement stmnt = con.createStatement();
		stmnt.executeUpdate("UPDATE student set mobile='962333228' where email='asif@gmail.com'");
	//close db connection
		con.close();
	} catch (Exception e) {
		e.printStackTrace();

	}
}
}

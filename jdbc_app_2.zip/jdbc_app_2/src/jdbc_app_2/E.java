package jdbc_app_2;

public class E {

}

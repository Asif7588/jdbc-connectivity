package jdbc_app_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class B {
 public static void main(String[] args) {
	try {
		//connect to db
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_db_1", "root", "asif");
		
	System.out.println(con);	
	//create statements
	Statement stmnt = con.createStatement();
		stmnt.executeUpdate("DELETE FROM student WHERE email='stallin@gmail.com'");
	//close db connection
		con.close();
	} catch (Exception e) {
		e.printStackTrace();

	}
}
}
